# Scoring Schema

Seven criteria (0–100) with weights:
- Adoption/Ecosystem
- Image Quality
- Speed/Uptime
- Cost/Free Tier
- Trust/Safety
- Automation/Innovation
- Ethical/Environmental

Normalize metrics, apply weights, compute total, snapshot daily, display deltas.
