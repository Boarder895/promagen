import ApiKeysPanel from "../../components/ApiKeysPanel";
export default function Page() { return <ApiKeysPanel />; }
