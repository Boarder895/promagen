export default function BulkLeaderboardPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1 style={{ marginTop: 0 }}>Bulk Leaderboard (UI)</h1>
      <p>This page lives outside <code>/app/api</code> to avoid Next.js routing conflicts.</p>
    </main>
  )
}


