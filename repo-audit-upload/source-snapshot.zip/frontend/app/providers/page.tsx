// app/providers/page.tsx
import { ProviderGrid } from "@/components/ProviderGrid";

export default function ProvidersPage() {
  return <ProviderGrid />;
}

