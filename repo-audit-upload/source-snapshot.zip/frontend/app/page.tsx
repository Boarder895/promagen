export default function HomePage() {
  return (
    <main>
      Home. Try <a href="/settings/keys">Settings ? Keys</a>.
    </main>
  );
}
