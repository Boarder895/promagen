'use client';

import PromagenMVP from '@/components/PromagenMVP';

export default function ClientShell() {
  return <PromagenMVP />;
}

