// Temporary stub for deploy; replace with real Prisma in the API later.
const prisma: any = {};
export default prisma;
