# 🏗 Promagen — Build Progress Book

<!-- include: partials/_principles.md -->
<!-- include: partials/_shipped.md -->
<!-- include: partials/_in-progress.md -->
<!-- include: partials/_todo-near.md -->
<!-- include: partials/_todo-medium.md -->

## Changelog

### 2025-09-27
- ✅ Dual-option Prompt Runner highlighted (⚡ + ✂️)
- ✅ Score Adjustment Editor live with clamping
- 🟪 Provider badges integrated into plan (⚡/✂️/💎)

### 2025-09-20
- 🟡 App Router migration (partial)
- ✅ PROD API default, admin endpoints live
