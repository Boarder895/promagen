## ✅ Shipped
- App Router skeleton & base routes (`/admin`, `/demo/sse`, `/demo/runs`, `/providers`, `/docs/*`)
- Option A provider registry and demo generation simulator
- Jobs stream simulator and UI wiring
- Docs layout & sidebar with route-scoped styles
- `/prompt` playground (simulated run)
- `/leaderboard` page (provider list)
