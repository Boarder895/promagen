## 🧪 In progress
- Docs TOC wiring & content tidy
- Demo polish (loading/empty/error states, type clean-ups)
