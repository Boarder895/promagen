## 🎯 Medium-term
- Backend API integration for “real” providers (feature-flagged) (**Functionality, Longevity, Cost**)
- Rate limiting & safety guards (**Functionality, Longevity**)
- Basic telemetry (anonymous) (**Longevity, Ease**)
