﻿[![Generate Docs from Source](https://github.com/<owner>/<repo>/actions/workflows/update-docs.yml/badge.svg)](https://github.com/<owner>/<repo>/actions/workflows/update-docs.yml)

# Promagen

