'use client';

import * as React from 'react';

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

export default ProgressProvider;
