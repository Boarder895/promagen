"use client";
export default function ServiceBanner() { return null; }
