export function LeftNav() {
  return <nav className="p-4">Left Nav</nav>;
}
export default LeftNav; // ✅ adds default export to satisfy default-imports


