"use client";
import books from "@/data/books"; // Next can bundle JSON for client

export function loadClientBooks() {
  return books;
}


