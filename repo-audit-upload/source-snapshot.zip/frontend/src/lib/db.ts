// Temporary stub to satisfy imports during deploy.
// Replace with a real Prisma client (in the API) later.
const prisma: any = {};
export default prisma;
