declare const prisma: any;
export default prisma;
