declare module '@/components/DocsTOC' {
  const Component: React.ComponentType<any>;
  export default Component;
}

declare module '@/components/DocsSidebar' {
  const Component: React.ComponentType<any>;
  export default Component;
}


