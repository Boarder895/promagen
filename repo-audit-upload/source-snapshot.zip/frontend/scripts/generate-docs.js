PASTE THE JS FROM "scripts/generate-docs.js" HERE
