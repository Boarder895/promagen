import "dotenv/config";

export const keys = {
  openai: process.env.OPENAI_API_KEY ?? "",
};
