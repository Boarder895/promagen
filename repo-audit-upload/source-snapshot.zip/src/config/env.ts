// src/config.ts
export const FEATURE_CREDITS =
  (process.env.FEATURE_CREDITS ?? "off").toLowerCase() === "on";
