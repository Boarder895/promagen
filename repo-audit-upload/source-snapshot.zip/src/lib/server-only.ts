// src/lib/server-only.ts
import "server-only"; // importing this in client code throws at build
