# Minimal reminder; use the full checker from chat for audits.
Write-Host "Use your Promagen checker script from ChatGPT to compare expected vs actual." -ForegroundColor Yellow
