DROP TABLE IF EXISTS "ApiCredential";
