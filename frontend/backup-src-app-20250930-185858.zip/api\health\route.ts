import { NextRequest, NextResponse } from 'next/server';

function normalizeBase(b: string | null): string {
  const base =
    (b && b.trim()) ||
    process.env.NEXT_PUBLIC_API_BASE_URL ||
    'https://promagen-api.fly.dev';
  return base.replace(/\/+$/, '');
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const base = normalizeBase(searchParams.get('base'));
  const upstream = `${base}/health`;

  try {
    const res = await fetch(upstream, { cache: 'no-store' });
    const text = await res.text().catch(() => '');
    return new NextResponse(text || '', { status: res.status, headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return new NextResponse('unreachable', { status: 502 });
  }
}
