import React from "react";
import ProviderGrid from "@/components/ProviderGrid";

export const revalidate = 60;

export default function ProvidersPage() {
  return (
    <main className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Providers</h1>
      {/* Prefer the new prop; legacy `filter` still supported */}
      <ProviderGrid kind="all" />
    </main>
  );
}
