import PromagenMVP from "@/components/PromagenMVP";
export default function Page() { return <PromagenMVP />; }
